#!/system/bin/sh
if ! applypatch -c EMMC:/dev/block/mmcblk0p5:5277696:5dc2df624ab3143da184829d78db26e755efbfd2; then
  log -t recovery "Installing new recovery image"
  applypatch EMMC:/dev/block/mmcblk0p4:4265984:2a2e3557e3a2868831b6fc29a81ccf672a43a333 EMMC:/dev/block/mmcblk0p5 5dc2df624ab3143da184829d78db26e755efbfd2 5277696 2a2e3557e3a2868831b6fc29a81ccf672a43a333:/system/recovery-from-boot.p
else
  log -t recovery "Recovery image already installed"
fi
